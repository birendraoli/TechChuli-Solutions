# TechChuli-Solutions
This is the TechChuli Solutions Official site repo


# Font falily used
font-family: 'Jost', sans-serif;
font-family: 'Montserrat', sans-serif;
font-family: 'Mooli', sans-serif;
font-family: 'PT Sans', sans-serif;
font-family: 'Roboto', sans-serif;
font-family: 'Signika Negative', sans-serif;
font-family: 'Ubuntu', sans-serif;
font-family: 'Varela Round', sans-serif;